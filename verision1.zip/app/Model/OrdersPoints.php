<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrdersPoints extends Model
{
    protected $table="orders_points";
    use HasFactory;
}
